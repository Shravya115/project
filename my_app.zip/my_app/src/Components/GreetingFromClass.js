import React, { Component } from 'react'

export default class GreetingFromClass extends Component {
  render() {
    return (
      <div>
        <h1>Have a nice day{this.props.name}</h1>
        <h1>age:22 {this.props.age}</h1>
        </div>
    )
  }
}
