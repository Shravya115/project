import React, { Component } from 'react'

export default class ClassComponent extends Component {
    constructor()
    {
        super();
        this.state={
        Message:'Shravya S'
        };
    }
  render() {
    return (
      <div>
        <h1>{this.state.Message} </h1>
      </div>
    )
  }
}
