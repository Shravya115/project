import React from 'react'

function GreetingComponent(props) {
  return (
    <div>
      <h1>Hello Good Morning{props.name}</h1>
      <h1>Had Breakfast{props.name}</h1>
    </div>
  )
}

export default GreetingComponent